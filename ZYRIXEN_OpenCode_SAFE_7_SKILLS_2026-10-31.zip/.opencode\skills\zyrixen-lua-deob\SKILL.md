---
name: zyrixen-lua-deob
description: Orchestrate evidence-based static and isolated runtime deobfuscation of Lua/Luau and Roblox scripts. Identify Luraph, Centurion, IronBrew, MoonSec, MoonVeil, SS7, and encoded strings; route to installed specialist skills and validated local decoders; produce verified readable .lua without inventing original source.
compatibility: opencode
metadata:
  audience: reverse-engineering
  scope: lua-luau
---

# Zyrixen Lua/Luau Deobfuscation Orchestrator

## Objective
Work on Lua/Luau source or VM-protected code supplied by the user. Prefer output artifacts to commentary. Preserve original behavior as far as evidence supports. Use installed skills as guidance, not proof that a decoder exists.

## 0. Triage and safety
- Work on the supplied file or URL and save its SHA256 and byte length.
- Treat unknown scripts as hostile input; DO NOT run arbitrary Roblox executors, payloads, or network requests on the host machine. If dynamic analysis is necessary, use only an isolated, disposable runtime with no credentials and controlled network access.
- Never claim a source file is fully recovered unless runnable behavior or equivalent test traces match.
- Preserve the input unchanged in `original/`; write new results under `out/`.

## 1. Detect fingerprint BEFORE selecting a specialist
- Low complexity: literal encodings, array lookups, escaped strings, base64/base85, XOR, simple lexical or structural transforms.
- VM-protected: dispatch loop, instruction stream, constant pool, opcode handlers, register table, nested prototypes, flattened CFG, or magic container.
- Luraph family: header/watermarks, encoded pool, custom virtual machine; distinguish variants instead of assuming v15 from one marker.
- Centurion/CTN: `CTN: decompression error`, `buffer.fromstring`, `buffer.readu8`, `loadstring(...,"Centurion")`, compressed/encoded first-stage payload.
- MoonVeil: version watermark plus VM/decoder structure; test independently on new samples.
- SS7 ENC: `SS7 ENC v3.7`, `SAFE85_CS`, blob identifier, `SS7V` magic; only trust decoder after container checks pass.
- Other families: MoonSec, IronBrew, Cypher, Grook, unknown custom VMs.

## 2. Choose helpers by target
Load these installed skills only if visible and relevant; missing skills are optional and should not block progress.
- Encoded/flattened code: `code-obfuscation-deobfuscation`.
- VM and opcode work: `reverse-engineering`, `ctf-reverse`, `dsl-vm-reverse` (JS VM analogies only).
- JavaScript loaders or backend: `js-reverse`, `deobfuscate-javascript` (dynamic evaluation disabled; never execute unpacked payload on host).
- Luau syntax/API validation: `roblox-agent-checks` (requires a Rojo project); use official Luau/Roblox docs otherwise. Do not install or invoke the removed `roblox-dev-skill`.
- Binaries or native components: `reverse-engineer-anything` (only for authorized analysis, and follow its separate gates).
Prefer existing local decoding scripts and prior verified playbooks. Never overwrite or remove working tools merely because a new one is available.

## 3. Static pipeline
1. Inventory source, search watermark/entry points, extract string and blob constants; save fingerprint evidence.
2. Apply non-executing string/container decoders first, recording transform and counts.
3. If VM exists: recover header/prototypes/constants/opcodes and dispatcher semantics, model instruction format, rebuild basic blocks and control flow, then emit Lua/Luau.
4. Remove dead decode scaffolding only when dataflow proves it unused; rename registers with evidence. Do not blindly strip R1/R15/PC.
5. For partial success, save real recovered code (not fabricated logic), annotated with unresolved regions in a separate report.

## 4. Runtime fallback
If static reconstruction stalls after meaningful attempts:
- Determine whether the blocker is dynamic keys, unsupported opcode, anti-tamper, or external network/server-gated code.
- In an isolated and explicitly approved test runtime, record only necessary decoded chunks, interpreter traces, constants, and dependencies; guard any execution against filesystem/network/credential access.
- When a valid authorization/key is required, do not claim payload can be dumped before authorization actually succeeds.
- Compare runtime traces with emulator/static reconstruction; revisit mismatches. If no safe runtime is available, mark `runtime needed`.

## 5. Output contract
- Default output: `out/<original-stem> deobsefactor by zyrixen.lua` with first line `-- deobsefactor by zyrixen`.
- Include recovered whole program when possible, not just UI snippets. Preserve actual user-defined logic.
- Produce `out/<original-stem>.deob-report.md` with fingerprint, input hash, stage-by-stage evidence, concrete decoded counts, tests performed, unresolved blocks, and status: `full`, `partial`, or `runtime needed`.
- Do not claim any percentage, feature, source restoration, or pass/fail without supporting evidence.
- If the user asks for a file, provide the real artifact and its path, not a placeholder or an invented link.

## 6. Playbook retention
Save generalizable method and obfuscator signature under `playbooks/<family>/<variant>.md`: indicators, container/VM layout, key derivation (if known and reproducible), scripts used, failed cases, and regression tests. Avoid sample-specific hardcoding.
