ZYRIXEN OPENCODE SAFE SKILLS - 31 October 2026
==========================================================
7 SKILLS: zyrixen-lua-deob, code-obfuscation-deobfuscation,
ctf-reverse, reverse-engineering, reverse-engineer-anything,
roblox-agent-checks, deobfuscate-javascript.

REMOVED: roblox-dev-skill (Critical warning, not included).
SECURITY PATCH: JS unpacker dynamic new Function eval disabled.
No downloaded installers are part of this package.

INSTALL (OFFLINE):
1. Extract this ZIP anywhere (do not execute scripts before reviewing).
2. Open CMD inside the extracted folder (where INSTALL_SAFE.cmd appears).
3. Run: INSTALL_SAFE.cmd "C:\your\OpenCode\project"
   Example: INSTALL_SAFE.cmd "C:\tuhas kp"
4. Reopen OpenCode from your project folder.
5. Prompt: Gunakan skill zyrixen-lua-deob untuk analisis Lua/Luau.

NOTE:
- INSTALL_SAFE.cmd only copies missing skill folders, it never overwrites existing skills.
- This is a static audit, NOT a malware-free guarantee.
- Use isolated runtime for untrusted Lua/Luau and JavaScript samples.
- For additional tool scripts from your private ZyrixenTools folder, use existing project separately.
- Skill content may reference their third-party authors. Keep their licenses.