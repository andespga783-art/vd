import { s as e } from "./chunk-Bj-mKKzh.js";
import { n as t, t as n } from "./jsx-runtime-CiQ1k8xo.js";
import { t as r } from "./clsx-DDuZWq6Y.js";
import { X as i, xt as a } from "./setting-storage-EK1Te68s.js";
import { r as o } from "./reduced-motion-preference-CcGC6Z5k.js";
function s() {
  return i(o);
}
e(t());
var c = n(),
  l = (e) =>
    (0, c.jsxs)(`svg`, {
      width: 24,
      height: 24,
      viewBox: `0 0 24 24`,
      fill: `none`,
      xmlns: `http://www.w3.org/2000/svg`,
      ...e,
      children: [
        (0, c.jsx)(`path`, {
          opacity: 0.3,
          d: `M18 12C18 8.68629 15.3137 6 12 6C8.68629 6 6 8.68629 6 12C6 15.3137 8.68629 18 12 18C15.3137 18 18 15.3137 18 12ZM20 12C20 16.4183 16.4183 20 12 20C7.58172 20 4 16.4183 4 12C4 7.58172 7.58172 4 12 4C16.4183 4 20 7.58172 20 12Z`,
          fill: `currentColor`,
        }),
        (0, c.jsx)(`path`, {
          d: `M12 4C16.4183 4 20 7.58172 20 12C20 16.4183 16.4183 20 12 20C7.58172 20 4 16.4183 4 12H6C6 15.3137 8.68629 18 12 18C15.3137 18 18 15.3137 18 12C18 8.68629 15.3137 6 12 6V4Z`,
          fill: `currentColor`,
        }),
      ],
    }),
  u = a();
function d(e) {
  let t = (0, u.c)(10),
    { className: n, animationDurationMs: i } = e,
    a = s(),
    o = `-${Date.now() % 1e3}ms`,
    d = i == null ? void 0 : `${i}ms`,
    f = !a && `animate-spin`,
    p;
  t[0] === f
    ? (p = t[1])
    : ((p = r(
        f,
        `inline-flex h-fit w-fit items-center justify-center leading-none contain-layout contain-paint contain-style`,
      )),
      (t[0] = f),
      (t[1] = p));
  let m;
  t[2] === d
    ? (m = t[3])
    : ((m = { animationDelay: o, animationDuration: d }),
      (t[2] = d),
      (t[3] = m));
  let h;
  t[4] === n
    ? (h = t[5])
    : ((h = (0, c.jsx)(l, { className: n })), (t[4] = n), (t[5] = h));
  let g;
  return (
    t[6] !== p || t[7] !== m || t[8] !== h
      ? ((g = (0, c.jsx)(`div`, { className: p, style: m, children: h })),
        (t[6] = p),
        (t[7] = m),
        (t[8] = h),
        (t[9] = g))
      : (g = t[9]),
    g
  );
}
export { l as n, s as r, d as t };
//# sourceMappingURL=spinner-D37df5tU.js.map
