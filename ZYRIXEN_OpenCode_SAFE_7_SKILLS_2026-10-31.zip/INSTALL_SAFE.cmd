@echo off
setlocal EnableExtensions DisableDelayedExpansion
if "%~1"=="" (
  echo Usage: INSTALL_SAFE.cmd "C:\your\OpenCode\project"
  echo Example: INSTALL_SAFE.cmd "C:\tuhas kp"
  exit /b 1
)
set "SRC=%~dp0"
set "DST=%~1"
if not exist "%DST%" (
  echo Project folder not found: %DST%
  exit /b 1
)
if not exist "%DST%\.agents\skills" mkdir "%DST%\.agents\skills"
if not exist "%DST%\.opencode\skills" mkdir "%DST%\.opencode\skills"
for /d %%S in ("%SRC%.agents\skills\*") do (
  if exist "%DST%\.agents\skills\%%~nxS" (
    echo [SKIP] %%~nxS already installed. Existing file kept.
  ) else (
    xcopy "%%~fS" "%DST%\.agents\skills\%%~nxS\" /E /I /Q /H >nul
    if errorlevel 1 (
      echo [ERROR] Failed copying %%~nxS
      exit /b 1
    )
    echo [INSTALLED] %%~nxS
  )
)
if exist "%DST%\.opencode\skills\zyrixen-lua-deob" (
  echo [SKIP] zyrixen-lua-deob already installed. Existing file kept.
) else (
  xcopy "%SRC%.opencode\skills\zyrixen-lua-deob" "%DST%\.opencode\skills\zyrixen-lua-deob\" /E /I /Q /H >nul
  if errorlevel 1 exit /b 1
  echo [INSTALLED] zyrixen-lua-deob
)
echo Done. Restart OpenCode from %DST%
endlocal