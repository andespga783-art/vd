import { t as e } from "./jsx-runtime-CiQ1k8xo.js";
import { t } from "./clsx-DDuZWq6Y.js";
import { xt as n } from "./setting-storage-EK1Te68s.js";
import { t as r } from "./spinner-D37df5tU.js";
var i = {
    default: `rounded-full`,
    icon: `rounded-full electron:rounded-md`,
    iconSm: `rounded-md`,
    large: `rounded-full`,
    medium: `rounded-lg`,
    composer: `rounded-full`,
    composerSm: `rounded-full`,
    toolbar: `rounded-lg`,
  },
  a = n(),
  o = e(),
  s = {
    danger: `bg-token-charts-red/10 text-token-charts-red border-transparent`,
    ghost: `text-token-text-tertiary enabled:hover:bg-token-list-hover-background data-[state=open]:bg-token-list-hover-background border-transparent`,
    outlineActive: `border-token-border text-token-button-tertiary-foreground bg-token-foreground/10 enabled:hover:bg-token-foreground/15 data-[state=open]:bg-token-foreground/15 border`,
    ghostActive: `text-token-foreground enabled:hover:bg-token-list-hover-background data-[state=open]:bg-token-list-hover-background border-transparent`,
    ghostMuted: `text-token-muted-foreground enabled:hover:bg-transparent data-[state=open]:bg-transparent hover:text-token-foreground border-transparent`,
    outline: `border-token-border text-token-button-tertiary-foreground bg-token-bg-fog enabled:hover:bg-token-list-hover-background data-[state=open]:bg-token-list-hover-background border`,
    primary: `bg-token-foreground enabled:hover:bg-token-foreground/80 data-[state=open]:bg-token-foreground/80 text-token-dropdown-background`,
    secondary: `text-token-foreground bg-token-foreground/5 enabled:hover:bg-token-foreground/10 data-[state=open]:bg-token-foreground/10 border-transparent`,
  },
  c = {
    composer: `h-token-button-composer px-2 py-0 text-sm leading-[18px]`,
    composerSm: `h-token-button-composer-sm px-1.5 py-0 text-sm leading-[18px]`,
    default: `px-2 py-0.5 text-sm leading-[18px]`,
    icon: `electron:p-1 electron:[&>svg]:icon-sm flex items-center justify-center p-0.5`,
    iconSm: `flex h-4 w-4 items-center justify-center p-0.5 [&>svg]:icon-2xs`,
    large: `px-5 py-2 text-base leading-[18px]`,
    medium: `px-4 py-1.5 text-base leading-[18px]`,
    toolbar: `h-token-button-composer px-2 py-0 text-base leading-[18px]`,
  };
function l(e) {
  let n = (0, a.c)(25),
    l,
    u,
    d,
    f,
    p,
    m,
    h,
    g,
    _;
  n[0] === e
    ? ((l = n[1]),
      (u = n[2]),
      (d = n[3]),
      (f = n[4]),
      (p = n[5]),
      (m = n[6]),
      (h = n[7]),
      (g = n[8]),
      (_ = n[9]))
    : (({
        uniform: f,
        color: p,
        size: m,
        disabled: h,
        className: u,
        children: l,
        type: _,
        loading: g,
        ...d
      } = e),
      (n[0] = e),
      (n[1] = l),
      (n[2] = u),
      (n[3] = d),
      (n[4] = f),
      (n[5] = p),
      (n[6] = m),
      (n[7] = h),
      (n[8] = g),
      (n[9] = _));
  let v = f === void 0 ? !1 : f,
    y = p === void 0 ? `primary` : p,
    b = m === void 0 ? `default` : m,
    x = h === void 0 ? !1 : h,
    S = g === void 0 ? !1 : g,
    C = _ ?? `button`,
    w = i[b],
    T = s[y],
    E = c[b],
    D;
  n[10] !== u || n[11] !== w || n[12] !== T || n[13] !== E || n[14] !== v
    ? ((D = t(
        `border-token-border user-select-none no-drag cursor-interaction flex items-center gap-1 border whitespace-nowrap focus:outline-none disabled:cursor-not-allowed disabled:opacity-40`,
        w,
        T,
        E,
        { true: `aspect-square items-center justify-center !px-0`, false: `` }[
          v ? `true` : `false`
        ],
        u,
      )),
      (n[10] = u),
      (n[11] = w),
      (n[12] = T),
      (n[13] = E),
      (n[14] = v),
      (n[15] = D))
    : (D = n[15]);
  let O = x || S,
    k;
  n[16] === S
    ? (k = n[17])
    : ((k = S && (0, o.jsx)(r, { className: `icon-xxs` })),
      (n[16] = S),
      (n[17] = k));
  let A;
  return (
    n[18] !== l ||
    n[19] !== d ||
    n[20] !== D ||
    n[21] !== O ||
    n[22] !== k ||
    n[23] !== C
      ? ((A = (0, o.jsxs)(`button`, {
          type: C,
          className: D,
          disabled: O,
          ...d,
          children: [k, l],
        })),
        (n[18] = l),
        (n[19] = d),
        (n[20] = D),
        (n[21] = O),
        (n[22] = k),
        (n[23] = C),
        (n[24] = A))
      : (A = n[24]),
    A
  );
}
export { i as n, l as t };
//# sourceMappingURL=button-bq66r8jD.js.map
